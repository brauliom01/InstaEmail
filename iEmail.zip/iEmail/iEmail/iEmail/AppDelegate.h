//
//  AppDelegate.h
//  iEmail
//
//  Created by Braulio Martin on 2/8/23.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>


@end

