//
//  SceneDelegate.h
//  iEmail
//
//  Created by Braulio Martin on 2/8/23.
//

#import <UIKit/UIKit.h>

@interface SceneDelegate : UIResponder <UIWindowSceneDelegate>

@property (strong, nonatomic) UIWindow * window;

@end

