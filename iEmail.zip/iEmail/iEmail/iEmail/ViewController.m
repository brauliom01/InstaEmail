//
//  ViewController.m
//  iEmail
//
//  Created by Braulio Martin on 2/8/23.
//

#import "ViewController.h"

@interface ViewController (){
NSArray* activities;
NSArray* feelings;
}

@property (weak, nonatomic) IBOutlet UIPickerView *emailPicker;
@property (weak, nonatomic) IBOutlet UITextField *notesField;

@end

@implementation ViewController
@synthesize emailPicker=emailPicker;
//@synthesize activities=activities;
//@synthesize feelings=feelings;


- (void)viewDidLoad {
    [super viewDidLoad];
    
    activities = [[NSArray alloc] initWithObjects: @"sleeping",@"eating",@"thinking",@"shopping", nil];
    feelings = [[NSArray alloc] initWithObjects: @"sad",@"eager",@"happy",@"hopeful", nil];
    // Do any additional setup after loading the view.
}

#pragma mark - PickerDataSource Protocol

-(NSInteger)numberOfComponentsInPickerView:(UIPickerView *)pickerView{
    return 2;
}

-(NSInteger)pickerView:(UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component{
    return component == 0 ? [activities count] : [feelings count];
}

#pragma mark - PickerDelegate Protocol

- (NSString *)pickerView:(UIPickerView *)pickerView titleForRow:(NSInteger)row
            forComponent:(NSInteger)component {
    if (component > 1) { return nil; }
    return [(component == 0 ? activities : feelings) objectAtIndex:row];
    }

- (IBAction)sendPressed:(id)sender {
    
    NSString *activity = [activities objectAtIndex: [emailPicker selectedRowInComponent:0]];
    NSString *feeling = [feelings objectAtIndex: [emailPicker selectedRowInComponent:1]];
    
    NSString *notes = [_notesField text];
    
    NSString* theMessage = [NSString stringWithFormat:@"I'm %@ and feeling %@ about it! %@", activity, feeling, notes];
    
    NSLog(@"%@", theMessage);
    
    if ([MFMailComposeViewController canSendMail]){
        MFMailComposeViewController* mc = [[MFMailComposeViewController alloc] init];
        mc.mailComposeDelegate = self;
        [mc setToRecipients:[[NSArray alloc] initWithObjects:@"brauliom01@yahoo.com", nil]];
        [mc setSubject:@"Hello, Webb!"];
        [mc setMessageBody:theMessage isHTML:NO];
        
        [self presentViewController:mc animated:YES completion:nil];
    }
    else{
        NSLog(@"%@", @"Sorry, you need to set up mail first!");
    }
}

- (IBAction)doneEditing:(id)sender {
    [sender resignFirstResponder];
}


#pragma mark - MailComposer delegate method
- (void)mailComposeController:(MFMailComposeViewController *)controller didFinishWithResult:(MFMailComposeResult)result error:(NSError *)error{
    [self dismissViewControllerAnimated:YES completion:nil];
}


@end
